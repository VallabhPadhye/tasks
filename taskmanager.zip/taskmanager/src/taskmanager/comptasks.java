/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package taskmanager;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.HeadlessException;
import java.awt.Toolkit;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;
import net.proteanit.sql.DbUtils;

/**
 *
 * @author Dell
 */
public final class comptasks extends javax.swing.JFrame {

    /**
     * Creates new form comptasks
     */
    public comptasks() {
        initComponents();
        this.setTitle("Tasks ©Dcoder Solutions.");
        this.setResizable(false);
         this.setSize(new Dimension(799,685));
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
	this.setLocation(screenSize.width - this.getWidth(), screenSize.height - this.getHeight() - 50);
        loadtable();
        loadtaskid();  
        emptyhistory();
        this.setDefaultCloseOperation(Home.EXIT_ON_CLOSE);
        this.setDefaultCloseOperation(new_task.EXIT_ON_CLOSE);
        this.setDefaultCloseOperation(comptasks.EXIT_ON_CLOSE);
        ImageIcon icon = new ImageIcon("src/icons/appicon.png");
        setIconImage(icon.getImage());
    }
    
   
    public void loadtable() // loads data in table and formats header columns
    {      
          try{ 
        Statement s = dbcon.mycon().createStatement();
        ResultSet rs = s.executeQuery("Select * from completed order by taskid asc limit 1");
         if(rs.next()==false){
            JOptionPane.showMessageDialog(this,"Empty History!");
            new_task n1 = new new_task();
            this.dispose();
            n1.setVisible(true);
            
         }
               PreparedStatement pst = dbcon.mycon().prepareStatement("select taskid, subject ,start_date, due_date from completed");
               ResultSet r = pst.executeQuery();
               ctable.setModel(DbUtils.resultSetToTableModel(r));
               
               Object[] column = {"TASK ID", "SUBJECT","CREATED","EXPIRED"};
               DefaultTableModel model = new DefaultTableModel();
               model.setColumnIdentifiers(column);
               ctable.setModel(model);
             
            }catch(Exception e){}
          
             JTableHeader chead = ctable.getTableHeader();
             chead.setForeground(Color.BLACK);
             chead.setFont(new Font("TAHOMA", Font.BOLD,14));
             TableColumn column1 = ctable.getColumnModel().getColumn(0);
             column1.setPreferredWidth(200);
             TableColumn column2 = ctable.getColumnModel().getColumn(1);
             column2.setPreferredWidth(360);
             TableColumn column3 = ctable.getColumnModel().getColumn(2);
             column3.setPreferredWidth(100);
             TableColumn column4 = ctable.getColumnModel().getColumn(3);
             column4.setPreferredWidth(100);
             
    }
    
    public void loadtaskid()//loads task id's in combo box
    {
    taskidcombo.addItem("SELECT TASK ID");
        try{
         String sql = "select * from completed";
         PreparedStatement pst = dbcon.mycon().prepareStatement(sql);
         ResultSet rs = pst.executeQuery();
         while(rs.next())
         {   
             taskidcombo.addItem(rs.getString("taskid"));
         }
         }catch(Exception e){} 
    }
    void searchtask()    
    {
        try{
        String cell = (String)taskidcombo.getSelectedItem();
        String cell2 = "SELECT TASK ID"; 
         
         DefaultTableModel dt =  (DefaultTableModel) ctable.getModel();
         dt.setRowCount(0);
         Statement s = dbcon.mycon().createStatement();       
         if("SELECT TASK ID".equals(cell))
         {
              ResultSet rs = s.executeQuery("select taskid, subject ,start_date, due_date from completed");
         
         while (rs.next()) {             
             
             Vector v =new Vector();
             v.add(rs.getString(1));
             v.add(rs.getString(2));
             v.add(rs.getString(3));
             v.add(rs.getString(4));
             dt.addRow(v);
             
         }}
         else{
         ResultSet rs = s.executeQuery("select taskid, subject ,start_date, due_date from completed WHERE taskid like'%"+cell+"%'");
         
         while (rs.next()) {             
             
             Vector v =new Vector();
             v.add(rs.getString(1));
             v.add(rs.getString(2));
             v.add(rs.getString(3));
             v.add(rs.getString(4));
             dt.addRow(v);
             
         }    
         }
        }catch(Exception e){
            loadtable();
        }
    }
    public void emptyhistory() 
    {
       try{    
        Statement s = dbcon.mycon().createStatement();
        ResultSet rs = s.executeQuery("Select * from completed order by taskid asc limit 1");
         if(rs.next()==false)
         {
            JOptionPane.showMessageDialog(this,"Empty History!");
            new_task n1 = new new_task();
            this.dispose();
            n1.setVisible(true);   
        }}catch(InstantiationException | IllegalAccessException | SQLException | HeadlessException e){JOptionPane.showMessageDialog(this,e);}
    }
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        ctable = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        taskidcombo = new javax.swing.JComboBox();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuItem1 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(799, 685));
        setPreferredSize(new java.awt.Dimension(799, 685));
        getContentPane().setLayout(null);

        jPanel1.setBackground(new java.awt.Color(255, 0, 0));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("HISTORY");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, 800, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 0, 800, 50);

        jPanel2.setBackground(new java.awt.Color(102, 102, 255));
        jPanel2.setLayout(null);

        ctable.setAutoCreateRowSorter(true);
        ctable.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        ctable.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        ctable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        ctable.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        ctable.setEnabled(false);
        ctable.setRowHeight(20);
        jScrollPane1.setViewportView(ctable);

        jPanel2.add(jScrollPane1);
        jScrollPane1.setBounds(20, 120, 760, 330);

        jButton1.setBackground(new java.awt.Color(255, 0, 0));
        jButton1.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/delete_32.png"))); // NOI18N
        jButton1.setText("DELETE RECORD");
        jButton1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton1);
        jButton1.setBounds(350, 460, 210, 40);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("SEARCH:");
        jPanel2.add(jLabel1);
        jLabel1.setBounds(20, 60, 80, 30);

        taskidcombo.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        taskidcombo.setToolTipText("");
        taskidcombo.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        taskidcombo.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                taskidcomboItemStateChanged(evt);
            }
        });
        taskidcombo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                taskidcomboActionPerformed(evt);
            }
        });
        jPanel2.add(taskidcombo);
        taskidcombo.setBounds(100, 60, 240, 30);

        jButton2.setBackground(new java.awt.Color(255, 0, 0));
        jButton2.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/icons8_refresh_32.png"))); // NOI18N
        jButton2.setText("REFRESH");
        jButton2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton2);
        jButton2.setBounds(190, 460, 150, 40);

        jButton3.setBackground(new java.awt.Color(255, 0, 0));
        jButton3.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/delete_history_32.png"))); // NOI18N
        jButton3.setText("CLEAR HISTORY");
        jButton3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton3);
        jButton3.setBounds(570, 460, 210, 40);

        getContentPane().add(jPanel2);
        jPanel2.setBounds(0, 50, 800, 610);

        jMenuBar1.setBackground(new java.awt.Color(255, 255, 0));
        jMenuBar1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jMenuBar1.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N

        jMenu1.setText("Menu");
        jMenu1.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N

        jMenuItem2.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_B, java.awt.event.InputEvent.ALT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem2.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        jMenuItem2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/home_16.png"))); // NOI18N
        jMenuItem2.setText("Home");
        jMenuItem2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jMenuItem2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem2);

        jMenuItem1.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_N, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem1.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        jMenuItem1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/icons8_add_16.png"))); // NOI18N
        jMenuItem1.setText("New Task");
        jMenuItem1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jMenuItem1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem1);

        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        setSize(new java.awt.Dimension(817, 732));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        Home h1 = new Home();
        h1.loadctask();
        this.dispose();
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        new_task n = new new_task();
        n.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
         try{
            
         String cell = (String)taskidcombo.getSelectedItem();
         if(cell == null || cell == "SELECT TASK ID")
         {
            JOptionPane.showMessageDialog(this,"Please select TaskID.!","Error", JOptionPane.ERROR_MESSAGE);
         }
         else{
         String sql = "DELETE from completed where taskid like '%"+cell+"%'";
         PreparedStatement p = dbcon.mycon().prepareStatement(sql);
         p.executeUpdate();
         DefaultTableModel model = (DefaultTableModel)ctable.getModel();
         model.setRowCount(0);
         JOptionPane.showMessageDialog(this,"Record Deleted..!","",JOptionPane.OK_OPTION);
         }
         taskidcombo.removeAllItems();
         loadtaskid();
         this.setVisible(true);
         }catch(SQLException | HeadlessException e){JOptionPane.showMessageDialog(this,e,"Error",JOptionPane.ERROR_MESSAGE);} catch (InstantiationException ex) {
            Logger.getLogger(comptasks.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            Logger.getLogger(comptasks.class.getName()).log(Level.SEVERE, null, ex);
        }
         emptyhistory();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void taskidcomboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_taskidcomboActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_taskidcomboActionPerformed

    private void taskidcomboItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_taskidcomboItemStateChanged
       searchtask();
    }//GEN-LAST:event_taskidcomboItemStateChanged

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
         this.dispose();
         taskidcombo.removeAllItems();
         loadtaskid();
         loadtable();
         this.setVisible(true);
         
       
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
      
        
        int result = JOptionPane.showConfirmDialog(this, "Do you want to clear all history ?", "Confirmation ", JOptionPane.YES_NO_OPTION);
        if (result == JOptionPane.YES_OPTION)
           try{
                String sql = "DELETE from completed";
                PreparedStatement p = dbcon.mycon().prepareStatement(sql);
                p.executeUpdate();
                JOptionPane.showMessageDialog(this,"All history cleared...!","",JOptionPane.WARNING_MESSAGE);
                this.dispose();
                Home h1 = new Home();
                h1.setVisible(false);
                h1.loadctask();
                h1.loadntask();
                }catch(SQLException | HeadlessException e){JOptionPane.showMessageDialog(this,e,"Error",JOptionPane.ERROR_MESSAGE);} catch (InstantiationException ex) {
            Logger.getLogger(comptasks.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            Logger.getLogger(comptasks.class.getName()).log(Level.SEVERE, null, ex);
        }
      
       
    }//GEN-LAST:event_jButton3ActionPerformed

    /**
     * @param args the command line arguments
     */
   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable ctable;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JComboBox taskidcombo;
    // End of variables declaration//GEN-END:variables
}
